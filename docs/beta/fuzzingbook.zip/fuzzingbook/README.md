This folder holds the code from "Generating Software Tests".
Web site: https://www.fuzzingbook.org/

You can import it as in

```python
from fuzzingbook.Fuzzer import RandomFuzzer
f = RandomFuzzer()
f.fuzz()
```
	
or execute the files directly, as in

```shell
$ ./Fuzzer.py
```

Enjoy!	
