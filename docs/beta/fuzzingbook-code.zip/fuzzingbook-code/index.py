#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# This material is part of "Generating Software Tests".
# Web site: https://www.fuzzingbook.org/html/index.html
# Last change: 2018-09-18 13:44:14+02:00
#
# This material is licensed under a
# Creative Commons Attribution-NonCommercial-ShareAlike 4.0
# International License
# (https://creativecommons.org/licenses/by-nc-sa/4.0/)


# # About this Book
# 
# __Welcome to "Generating Software Tests"!__ 
# Software has bugs, and catching bugs can involve lots of effort.  This book addresses this problem by _automating_ software testing, specifically by _generating tests automatically_.  Recent years have seen the development of novel techniques that lead to dramatic improvements in test generation and software testing.  They now are mature enough to be assembled in a book – even with executable code. 

if __name__ == "__main__":
    print('# About this Book')




# ## A Textbook for Paper, Screen, and Keyboard
# 
# You can use this book in three ways:
# 
# * You can __read chapters in your browser__.  Check out the list of chapters in the menu above, or start right away with the 
# <a href="https://www.fuzzingbook.org/html/Intro_Testing.html">introduction to testing</a> or the
# <a href="https://www.fuzzingbook.org/html/Fuzzer.html">introduction to fuzzing</a>.  All code is available for download.
# 
# * You can __interact with chapters as Jupyter Notebooks__ (beta).  This allows you edit and extend the code, experimenting _live in your browser._  Just click on "Resources → Edit as Notebook" at the top of each chapter. <a href="https://mybinder.org/v2/gh/uds-se/fuzzingbook/master?filepath=notebooks/Fuzzer.ipynb" target=_blank>Try interacting with the introduction to fuzzing.</a>
# 
# * You can __present chapters as slides__ (beta).  This allows for presenting the material in lectures.  Just click on "Resources → View slides" at the top of each chapter. <a href="https://www.fuzzingbook.org/slides/Fuzzer.slides.html" target=_blank>Try viewing slides on the introduction to fuzzing.</a>

if __name__ == "__main__":
    print('\n## A Textbook for Paper, Screen, and Keyboard')




# ## Who this Book is for
# 
# This work is designed as a _textbook_ for a course in software testing; as _supplementary material_ in a software testing or software engineering course; and as a _resource for software developers_. We cover random fuzzing, mutation-based fuzzing, grammar-based test generation, symbolic testing, and much more, illustrating all techniques with code examples that you can try out yourself.

if __name__ == "__main__":
    print('\n## Who this Book is for')




# ## News
# 
# This book is _work in progress,_ with new chapters coming out every week.  To get notified when a new chapter comes out, <a href="https://twitter.com/FuzzingBook?ref_src=twsrc%5Etfw" data-show-count="false">follow us on Twitter</a>.
# 
# <a class="twitter-timeline" data-width="500" data-chrome="noheader nofooter noborders transparent" data-link-color="#A93226" data-align="center" href="https://twitter.com/FuzzingBook?ref_src=twsrc%5Etfw">News from @FuzzingBook</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
# 

if __name__ == "__main__":
    print('\n## News')




# ## About the Authors
# 
# This book is written by _Andreas Zeller, Rahul Gopinath, Marcel Böhme, Gordon Fraser, and Christian Holler_.  All of us are long-standing experts in software testing and test generation; and we have written or contributed to some of the most important test generators and fuzzers on the planet.  As an example, if you are reading this in a Firefox, Chrome, or Edge Web browser, you can do so safely partly because of us, as _the very techniques listed in this book have found more than 2,600 bugs in their JavaScript interpreters so far._  We are happy to share our expertise and making it accessible to the public.

if __name__ == "__main__":
    print('\n## About the Authors')




# ## Frequently Asked Questions

if __name__ == "__main__":
    print('\n## Frequently Asked Questions')




# ### Which content will be coming up?
# 
# The contents of this book will include topics such as:
# 
# 1. Introduction to Testing
# 2. Basic Fuzzing
# 3. Coverage
# 4. Mutation-Based Fuzzing
# 5. Grammar-Based Fuzzing
# 6. Fuzzing Function Calls
# 7. Fuzzing User Interfaces
# 8. Parsing and Mutating Inputs
# 9. Search-Based Testing
# 10. Symbolic Testing
# 11. Mining Grammars
# 12. Probabilistic Testing
# 13. Carving Unit Tests
# 14. Fuzzing and Invariants
# 15. Protection and Repair
# 
# See the table of contents in the menu above for those chapters that are already done.

if __name__ == "__main__":
    print('\n### Which content will be coming up?')




# ### Why does it take so long to start an interactive notebook?
# 
# We use the [binder](https://mybinder.org) service, which runs notebooks on their own servers.  Starting Jupyter through binder normally takes about 30 seconds. If, however, you are the first to invoke binder after a book update, binder recreates its environment, which can take a few minutes.  Note, though, that binder is officially in beta and we do not have control over binder.

if __name__ == "__main__":
    print('\n### Why does it take so long to start an interactive notebook?')




# ### I have a comment or a suggestion.  What do I do?
# 
# Report an issue on the [development page](https://github.com/uds-se/fuzzingbook/issues).

if __name__ == "__main__":
    print('\n### I have a comment or a suggestion.  What do I do?')




# ### I have reported an issue two weeks ago.  When will it be addressed?
# 
# We prioritize issues as follows:
# 
# 1. Bugs in code published on fuzzingbook.org
# 2. Bugs in text published on fuzzingbook.org
# 3. Writing missing chapters
# 4. Issues in yet unpublished code or text
# 5. Issues related to development or construction
# 6. Things marked as "beta"
# 7. Everything else

if __name__ == "__main__":
    print('\n### I have reported an issue two weeks ago.  When will it be addressed?')




# ### How can I solve problems myself?
# 
# We're glad you ask that.  The [development page](https://github.com/uds-se/fuzzingbook/) has all sources and some supplementary material.  Pull requests that fix issues are very welcome.

if __name__ == "__main__":
    print('\n### How can I solve problems myself?')




# ### How can I contribute?
# 
# Again, we're glad you're here!  See our [Guide for Authors](http://www.fuzzingbook.org/Guide_for_Authors.html) for instructions on coding and writing.

if __name__ == "__main__":
    print('\n### How can I contribute?')




# ### Do you provide PDFs of your material?
# 
# At this point, we do not provide support for PDF versions.  We are working on producing PDF and paper versions once the book is complete.

if __name__ == "__main__":
    print('\n### Do you provide PDFs of your material?')




# ### How do I cite your work?
# 
# Thanks for referring to our work!  Once the book is complete, you will be able to cite it in the traditional way.  In the meantime, just click on the "cite" button at the bottom of the Web page for each chapter to get a citation entry.

if __name__ == "__main__":
    print('\n### How do I cite your work?')



