This is the folder in which generated code is stored.
